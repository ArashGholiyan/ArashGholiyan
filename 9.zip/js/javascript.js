function DoWork(){
    var element = document.getElementById("Day");

    element.innerHTML = GetDay();
}
function GetDay(){
    var date = new Date();
    var dayNumber = date.getDay();
    var day = "";

    switch (dayNumber) {
        case 0:
            day = "یکشنبه";
            break;
        case 1:
            day = "دوشنبه";
            break;
        case 2:
            day = "سه شنبه";
            break;
        case 3:
            day = "چهارشنبه ";
            break;
        case 4:
            day = "پنجشنبه";
            break;
        case 5:
            day = "جمعه";
            break;
        case 6:
            day = "شنبه";
            break;
    }
            return day;
}